<?php
$salt = '';
$flag = 'Sorry tất cả các bạn vì challenge Web05 trước đã bị lỗi và thay thế bằng challenge lần này, goodjob <3, flag: ispclub{G00d_J0b_h4y_l4m_t41_n4ng_tr3!!!!!!!!⁢!__<3}, liên hệ với mình nhé: hypnguyen1209@gmail.com';
